import 'package:chatus/modules/auth/login/repository.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

class LoginController extends ChangeNotifier {
  final _repo = LoginRepository();

  bool _loading = false;
  bool get loading => _loading;

  Future<void> signIn(String email, String password, BuildContext context) async {
    _loading = true;
    notifyListeners();

    try {
      await _repo.signIn(email: email, password: password);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("signin Successful")));

      // Navigator.pushReplacementNamed(context, '/home');
    } catch (e) {
      if (kDebugMode) {
        print(e);
      }
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    }

    _loading = false;
    notifyListeners();
  }
}
